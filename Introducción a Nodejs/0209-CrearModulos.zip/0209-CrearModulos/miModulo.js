var miModulo = {
  saludo: function(){
    return "Hola, buenos dias";
  },
  despedida: function(){
    return "Adios, buenas noches";
  }
}

module.exports = miModulo;