var miModulo = require("./miModulo");

console.log(miModulo.saludo());
console.log(miModulo.despedida());