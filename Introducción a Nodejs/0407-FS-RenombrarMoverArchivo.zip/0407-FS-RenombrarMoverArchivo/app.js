var fs = require("fs");

/*
//Renombrar
fs.rename("./archivos/archivo.txt","./archivos/miArchivo.txt",(err)=>{
  if(err) throw err;
  console.log("Archivo renombrado");
});
*/

//Mover archivo
fs.rename("./archivos/miArchivo.txt","./miArchivo.txt",(err)=>{
  if(err) throw err;
  console.log("Archivo movido");
});

