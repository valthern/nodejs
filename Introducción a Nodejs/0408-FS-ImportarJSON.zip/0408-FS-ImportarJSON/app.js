// var grafica = require("./grafica.json");

// console.log(grafica.rows);

// for (var i = 0; i < 5; i++) {
//   console.log(grafica.rows[i].c[0].v, grafica.rows[i].c[1].v)
// }

var fs = require("fs");

fs.readFile("./grafica.json", (err, datos)=>{
  grafica = JSON.parse(datos);
  for (var i = 0; i < 5; i++) {
     console.log(grafica.rows[i].c[0].v, grafica.rows[i].c[1].v)
  }
});