var path = require("path");

console.log(path.parse('/home/user/dir/file.txt'));