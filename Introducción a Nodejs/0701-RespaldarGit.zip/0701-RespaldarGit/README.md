Amores perros
==========
- Baje la aplicación y ejecute:

```
npm install
```