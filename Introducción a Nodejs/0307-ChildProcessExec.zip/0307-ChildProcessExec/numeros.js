var process = require("process");

var interval = setInterval(()=>{
  numeros = "";
  for (var i = 0; i < 7; i++) {
    numeros = Math.floor((Math.random()*100)+1)+" ";
  }
  process.stdout.write(numeros+"\n");
},1000);

process.on('data',(data)=>{
  console.log("Buena suerte...");
  clearInterval(interval);
  process.exit();
});