var exec = require("child_process").exec;

//exec("explorer");

exec("git version", (err, salida)=>{
  if(err){
    throw err;
  }
  console.log(salida);

});