var fs = require("fs");

//var archivo = fs.readFileSync("./texto.txt");

var stream = fs.createReadStream("./texto.txt","UTF-8");

var texto = "";

stream.once("data",()=>{
  console.log("Inicio de carga");
});

stream.on("data", (textoParcial)=>{
  console.log("Caracteres leidos: ",textoParcial.length);
  texto += textoParcial;
});

stream.on("end",()=>{
  console.log("Texto leido: ",texto.length);
});
