var fs = require("fs");

/*
var archivos = fs.readdirSync("./");
console.log(archivos);
*/

//Asíncrona
fs.readdir("./", (err, archivos)=>{
  if (err) {
    throw err;
  }
  console.log(archivos);
});

console.log("Leyendo los archivos del directorio");