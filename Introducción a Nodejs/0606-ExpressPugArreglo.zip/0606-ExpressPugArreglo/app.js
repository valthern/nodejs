var express = require("express");
var app = express();

const pug = require("pug");

app.use(express.static(__dirname+"/public"));

var perros_array = [
  {raza:"Doberman",texto:"Perro de ataque",imagen:"doberman.jpg"},
  {raza:"Dachshund",texto:"Perro de caza",imagen:"dachshund.jpg"},
  {raza:"Pastor Alemán",texto:"Perro de pastoreo",imagen:"pastorAlemán.jpg"},
  {raza:"Pug",texto:"Perro de compañía",imagen:"pug.jpg"},
  {raza:"San Bernardo",texto:"Perro de rescate",imagen:"sanbernardo.jpg"},
]

app.get("/",(req,res)=>{
  //res.send("index.html");
  res.render("index.pug",{
    titulo: "Dachshund",
    texto: "El dachshund también es conocido como perro salchicha",
    imagen: "dachshund.jpg",
    perros: perros_array
  });
});

app.listen(3000,()=>{
  console.log("Servidor en el puerto 3000");
});