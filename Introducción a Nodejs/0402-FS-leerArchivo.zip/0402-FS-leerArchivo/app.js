var fs = require("fs");
var path = require("path");

fs.readdir("./archivos",(err, archivos)=>{

  archivos.forEach((archivo)=>{
    var file = path.join(__dirname, "archivos", archivo);
    var datos = fs.statSync(file);
    
    if(datos.isFile() && archivo!== ".DS_Store"){
      fs.readFile(file, "UTF-8", (err, data)=>{
        console.log(archivo,data);
        console.log("**********************");
      });
    }
  });

});