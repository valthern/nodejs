var fs = require("fs");

//syncrona
/*
try{
  fs.renameSync("./package.json","./package.txt");
} catch(err){
  console.log(err);
}
*/

//asincrona
/*
fs.rename("./package-lock.json","package-lock.txt", (err)=>{
if (err) {
  console.log(err);
} else {
  console.log("Archivo renombrado\n")
}
});
*/
//Sincrona
/*
try{
  fs.unlinkSync("./package.txt");
} catch(err){
  console.log(err);
}
*/
//asincrona
fs.unlink("package-lock.txt", (err)=>{
if (err) {
  console.log(err);
} else {
  console.log("Archivo eliminado\n")
}
});