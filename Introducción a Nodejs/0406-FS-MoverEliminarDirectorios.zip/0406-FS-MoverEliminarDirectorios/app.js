var fs = require("fs");

/*
fs.renameSync("./uno/dos","./dos");
console.log("Carpeta movida");
*/

//Borramos carpeta en forma sincrona
/*
fs.rmdirSync("./uno");
console.log("Carpeta borrada");
*/
//Borramos los archivos en forma síncrona
fs.readdirSync("./dos").forEach((archivo)=>{
  fs.unlinkSync("./dos/"+archivo);
});

//Borramos la carpeta en forma asincrona
fs.rmdir("./dos",(err)=>{
  if (err) {
    throw err;
  } else {
    console.log("Carpeta borrada");
  }
})