var path = require("path");
var saludo = "Hola cara de bola";

console.log(__filename);
console.log(__dirname);
console.log(`El archivo es ${path.basename(__filename)} se ejecuta`);