var moment = require("moment");

console.log(moment("2019-02-18").format("YYYY").toString());